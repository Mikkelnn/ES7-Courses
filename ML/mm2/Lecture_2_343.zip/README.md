1. Follow pyton direction from root README.md
    - Required packages: ´numpy matplotlib scikit-learn´
2. Run script:
    - Windows: `py -m ex01.py`
    - Linux: `python3 ex01.py`
